<!DOCTYPE HTML>
<html>
    <head>
        <title>Halaman Login</title>
        <link rel="stylesheet" href="tampil.css">
        <link rel="shortcut icon" type="image/icon" href="assets/logo/favicon.png"/>
    </head>
   
    <body>
        <div class="container">
          <h1>Login</h1>
            <form action="proses.php" method="post">
                
                <input type="text" name="email" placeholder="email"/><br>
             
                <input type="password" name="pass"placeholder="password"><br>
                <input type="submit" name="masuk" value="login"/><br>
				</form>
				

			<form >
			<button class="daftar"><a href="daftar.php">daftar</a> </button>
            <button class="kembali"><a href="../index.html">kembali</a> </button>
            
			</form>

			
                
        </div>     
    </body>
</html>