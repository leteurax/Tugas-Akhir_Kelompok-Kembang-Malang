<?php
$mysqli=mysqli_connect("localhost","root","","db_siswa2");
mysqli_select_db($mysqli,"db_siswa2") or die("Gagal terhubung ke database");
?>