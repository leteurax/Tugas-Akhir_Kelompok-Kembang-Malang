<?php
$mysqli=mysqli_connect("localhost","root","","tes");
mysqli_select_db($mysqli,"tes") or die("Gagal terhubung ke database");
?>