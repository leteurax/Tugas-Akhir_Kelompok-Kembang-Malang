<?php
    $conn = mysqli_connect('localhost','root','','kembang');
    if(!$conn){
        echo 'gagal terhubung data base';
    }
?>