<?php
    $conn = mysqli_connect('localhost','kembangm_mg','binus12345','kembangm_mg');
    if(!$conn){
        echo 'gagal terhubung data base';
    }
?>