<?php
    $connn = mysqli_connect('localhost','root','','kembang');
    if(!$connn){
        echo 'gagal terhubung ke data base';
    }
    
?>