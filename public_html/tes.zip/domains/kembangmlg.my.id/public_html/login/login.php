<!DOCTYPE HTML>
<html>
    <head>
        <title>Halaman Login</title>
        <link rel="stylesheet" href="tampil.css">
        <link rel="shortcut icon" type="image/icon" href="assets/logo/favicon.png"/>
        <script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="1c438f65-5c1a-471d-8952-8d64e6412309";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
    </head>
   
    <body>
        <div class="container">
          <h1>Login</h1>
            <form action="proses.php" method="post">
                
                <input type="text" name="email" placeholder="email"/><br>
             
                <input type="password" name="pass"placeholder="password"><br>
                <input type="submit" name="masuk" value="login"/><br>
				</form>
				

			<form >
			<button class="daftar"><a href="daftar.php">daftar</a> </button>
            <button class="kembali"><a href="../index.html">kembali</a> </button>
            
			</form>

			
                
        </div>     
    </body>
</html>